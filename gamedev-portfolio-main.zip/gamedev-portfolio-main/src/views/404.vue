<template>
  <div class="http-404">404 🙈</div>
</template>

<style scoped>
.http-404 {
  font-size: 11em;
  line-height: 3em;
  text-align: center;
}
</style>
